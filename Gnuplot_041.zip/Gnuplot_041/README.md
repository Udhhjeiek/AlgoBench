# AlgoBench - Benchmarking, Profiling & GNUplot module (CS25BT041)

This is Member 4's part of the project: a reusable engine that times, measures memory for,
and profiles **any** registered algorithm, writes results in the agreed CSV schema, and
draws GNUplot graphs. It has **no algorithm-specific logic** and uses only the Python
standard library (3.9+).

## Files

| Path | Purpose |
|---|---|
| `benchmarking/timer.py` | `time.perf_counter` trials, warm-up, fresh input copy per trial, avg/median/min/max/stdev |
| `benchmarking/memory_profiler.py` | `tracemalloc` peak extra memory (KiB), measured in a separate run |
| `benchmarking/profiler.py` | `cProfile`/`pstats` report, top-function table, bottleneck sentence, saves `.prof` + `.txt` |
| `benchmarking/benchmark_engine.py` | `BenchmarkEngine`: registry, `run()`, `sweep()`, CSV/JSON export, `load_csv()` |
| `benchmarking/gprof_profiler.py` | **gprof** for native C code: `gcc -pg` -> run -> `gprof` report + bottleneck sentence |
| `native/gprof_demo.c` | Small C program (naive matrix multiply) used to demonstrate gprof |
| `visualization/gnuplot/runtime_plot.gnuplot` | Runtime vs input size (log-log, error bars = stdev) |
| `visualization/gnuplot/memory_plot.gnuplot` | Peak memory vs input size |
| `visualization/gnuplot_runner.py` | Reads a CSV, builds `.dat` files, calls `gnuplot` for every category/input type |
| `test.py` | Unit tests + demo with stand-in sorting algorithms |

## 0. Setup (important)

Download/unzip the **whole project** (`AlgoBench_Member4_Benchmarking.zip`). `test.py` must sit
**next to** the `benchmarking/` and `visualization/` folders; copying only `test.py` and `README.md`
gives `ModuleNotFoundError: No module named 'benchmarking'`.

```
AlgoBench/
  test.py   README.md
  benchmarking/   visualization/   native/   results/
```

## 1. Test it on your machine

```bash
# from the project root (the folder containing test.py)
python test.py              # 17 unit tests, then a demo: CSV + profiling + plots
python test.py --no-demo    # unit tests only
python test.py --real       # also benchmarks Member 1's algorithms/sorting.py, once merged
```

Expected: `Ran 17 tests ... OK`, a results table, `results/sorting_demo.csv`,
profile reports in `results/profiles/`, and PNG graphs in `results/plots/`.

**gprof and GNUplot are optional for the tests**; missing tools are skipped with a message.

**GNUplot.** If it is not installed, the demo prints
"gnuplot not found -> skipped" and still prepares the `.dat` files. To get the graphs:

```bash
sudo apt install gnuplot      # Ubuntu/Debian
brew install gnuplot          # macOS
winget install gnuplot        # Windows (or download the installer from gnuplot.info,
                              #  tick "Add to PATH"; then open a NEW terminal)
gnuplot --version
```

Note: the plotting scripts could not be run in the environment where this code was written
(no gnuplot there). If `gnuplot` reports an error on your machine, send me the message
and I'll fix it.

## 2. Using the engine

```python
from benchmarking import BenchmarkEngine

engine = BenchmarkEngine(results_dir="results")

# Register algorithms (name them exactly as the dashboard will show them)
engine.register("sorting", "Quick Sort", quick_sort)                    # mutates input -> fresh copy each trial
engine.register("sorting", "Insertion Sort", insertion_sort, max_size=5000)   # O(n^2): skip bigger sizes
engine.register("searching", "Binary Search", binary_search, mutates_input=False)  # read-only: no copy

# One benchmark
row = engine.run("sorting", "Quick Sort", data, input_type="random", trials=10, profile=True)

# A whole experiment: dataset_factory(size, input_type, seed) -> input
rows = engine.sweep("sorting", ["Quick Sort", "Merge Sort"], [1000, 2000, 4000],
                    make_array, "random", trials=10, seed=42,
                    profile_largest=True, save_as="sorting_random.csv",
                    progress=lambda done, total, msg: ...)   # for a Streamlit progress bar
```

Result keys: `timestamp, category, algorithm, input_size, input_type, trial_count, average_time,
median_time, min_time, max_time, standard_deviation, memory_measurement, seed, notes`
(+ `raw_times`, and `profile` when requested; those two are not written to CSV).
Times are in **seconds**, `memory_measurement` is **KiB**.

Helpers for the dashboard (Member 5): `engine.list_result_files()`, `load_csv(path)`,
`engine.save_csv(rows, name, append=True)`, and `row["profile"]["text" | "rows" | "summary"]`.

### Interface rules the algorithm owners must follow
* The algorithm is called as `func(*args)`. If the dataset factory returns a **tuple**, it is unpacked
  into positional arguments, e.g. `(array, target)` -> `binary_search(array, target)`;
  anything else is passed as one argument. **Do not represent a graph as a bare tuple** (use a dict/class).
* Algorithms must **return** their result (printing alone is not enough).
* The factory is called once per size and every algorithm gets an identical copy, so comparisons are fair.
* Only the algorithm call is timed; copying/setup is excluded. For hash-table lookup, benchmark
  table construction and lookup as two separate registered functions (guide, section 5).

## 3. gprof (C code) and cProfile (Python code)

`cProfile` (`benchmarking/profiler.py`) profiles the **Python** algorithms. `gprof` can only profile
programs compiled with `gcc -pg`, so it is used for the **native C** part (Member 3's `native/matrix_fast.c`,
once it has a `main()` test driver; `native/gprof_demo.c` is a ready example).

```
python benchmarking/gprof_profiler.py native/gprof_demo.c results/gprof
```

| Platform | What to do |
|---|---|
| Linux / macOS | `sudo apt install gcc binutils`, then run the command above. |
| **Windows** | **Use WSL.** In an admin PowerShell: `wsl --install` (reboot), then inside Ubuntu: `sudo apt install gcc binutils`. After that the *same Windows command* works: the code detects WSL and runs gcc/gprof inside it automatically. |

Why not native Windows gcc (MinGW/MSYS2)? It compiles with `-pg`, but its gprof normally records **no time
samples**, giving an empty profile ("gprof recorded no time samples"). The tests then *skip* the gprof check
instead of failing. WSL/Linux is also the safest place to do the final demo evidence for gprof.
gprof is optional for this module: the main profiling evidence is cProfile, which works everywhere.

## 3b. Windows notes

All Python code is cross-platform. Run commands from the project root in **PowerShell**
(single-line commands; the `\` line-continuation used in Bash does not work in PowerShell).
GNUplot must be on PATH (`winget install gnuplot`, then open a new terminal). The Bash scripts and
Makefile belong to Member 5 and need Git Bash/WSL on Windows; they don't affect this module.

## 3c. GNUplot

```bash
python visualization/gnuplot_runner.py results/sorting_demo.csv results/plots
python visualization/gnuplot_runner.py results/sorting_demo.csv results/plots --linear --no-errbars
```

**Run `python test.py` first** - it creates `results/sorting_demo.csv`, which the command above reads.

Or call a script directly (one line, works in PowerShell, cmd and Bash):

```
gnuplot -e "datafile='results/plots/sorting_random.dat'; out='runtime.png'; n=3; plot_title='Sorting'" visualization/gnuplot/runtime_plot.gnuplot
```

For Member 5's `scripts/generate_all_plots.sh`, loop over the CSVs and call
`python visualization/gnuplot_runner.py "$csv" results/plots`.

## 4. Plugging in teammates' code

After merging their branches into your working copy, register their functions as above. The `--real`
flag of `test.py` shows the pattern for sorting (it looks for `quick_sort`, `merge_sort`, `heap_sort`,
`insertion_sort` in `algorithms/sorting.py`; rename in `test.py` if their function names differ).

## 5. Git hints

Work on your own branch, e.g. `git checkout -b benchmarking`, commit per module
(`timer`, `memory`, `profiler`, `engine`, `gnuplot`), and open a pull request to Member 5's integration branch.
Add `results/*.csv`, `results/plots/` and `results/profiles/` to `.gitignore` except any CSVs you want as report evidence.
